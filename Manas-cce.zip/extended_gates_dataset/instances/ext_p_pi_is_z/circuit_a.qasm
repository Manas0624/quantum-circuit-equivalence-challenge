OPENQASM 3.0;
include "stdgates.inc";
qubit[1] q;
p(pi) q[0];
