OPENQASM 3.0;
include "stdgates.inc";
qubit[2] q;
h q[1];
cx q[1], q[0];
swap q[0], q[1];
