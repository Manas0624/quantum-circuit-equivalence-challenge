OPENQASM 3.0;
include "stdgates.inc";
qubit[3] q;
h q[2];
ccx q[0], q[1], q[2];
h q[2];
